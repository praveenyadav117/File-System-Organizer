module.exports = {
  purge: [],
  theme: {
    container: {
      center: true,
      padding: '2rem'
    },
  },
  variants: {},
  plugins: [],
}

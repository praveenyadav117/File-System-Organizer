import React from 'react';
import './App.css';
import Flames from './Components';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Flames/>
      </header>
    </div>
  );
}

export default App;

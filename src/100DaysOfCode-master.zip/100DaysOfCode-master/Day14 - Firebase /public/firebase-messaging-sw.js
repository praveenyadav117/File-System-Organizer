importScripts('/__/firebase/7.18.0/firebase-app.js');
importScripts('/__/firebase/7.18.0/firebase-messaging.js');
importScripts('/__/firebase/init.js');

firebase.messaging();


export default( req, res) => {
    // console.log('req: ', req);
    // res.status(200).json({text: 'Hello'})
    <di>Hello</di>
}
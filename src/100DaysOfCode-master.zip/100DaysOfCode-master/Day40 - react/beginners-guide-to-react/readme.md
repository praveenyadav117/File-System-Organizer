This tutorial is a collection of learning from the tutorial by Kent C.Dodds egghead.io 

Free course - https://egghead.io/courses/the-beginner-s-guide-to-react